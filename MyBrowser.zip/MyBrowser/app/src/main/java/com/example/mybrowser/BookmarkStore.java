package com.example.mybrowser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BookmarkStore {

    public static final String DEFAULT_FOLDER = "General";

    public static class Bookmark {
        public String title;
        public String url;
        public String folder = DEFAULT_FOLDER;
        public Bookmark(String t, String u) { title = t; url = u; }
        public Bookmark(String t, String u, String f) { title = t; url = u; folder = (f == null || f.isEmpty()) ? DEFAULT_FOLDER : f; }
    }

    private final SharedPreferences sp;

    public BookmarkStore(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("bookmarks_v1", Context.MODE_PRIVATE);
    }

    public List<Bookmark> all() {
        List<Bookmark> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString("list", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Bookmark(o.optString("title", ""), o.optString("url", ""), o.optString("folder", DEFAULT_FOLDER)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void saveAll(List<Bookmark> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Bookmark b : list) {
                JSONObject o = new JSONObject();
                o.put("title", b.title);
                o.put("url", b.url);
                o.put("folder", b.folder);
                arr.put(o);
            }
            sp.edit().putString("list", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public boolean isBookmarked(String url) {
        for (Bookmark b : all()) if (b.url.equals(url)) return true;
        return false;
    }

    public void add(String title, String url) {
        List<Bookmark> list = all();
        for (Bookmark b : list) if (b.url.equals(url)) return; // no duplicates
        list.add(0, new Bookmark(title, url, DEFAULT_FOLDER));
        saveAll(list);
    }

    public void removeByUrl(String url) {
        List<Bookmark> list = all();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).url.equals(url)) { list.remove(i); break; }
        }
        saveAll(list);
    }

    public void renameByUrl(String url, String newTitle) {
        List<Bookmark> list = all();
        for (Bookmark b : list) if (b.url.equals(url)) { b.title = newTitle; break; }
        saveAll(list);
    }

    public void setFolder(String url, String folder) {
        List<Bookmark> list = all();
        for (Bookmark b : list) if (b.url.equals(url)) { b.folder = (folder == null || folder.isEmpty()) ? DEFAULT_FOLDER : folder; break; }
        saveAll(list);
    }

    public List<String> allFolders() {
        List<String> folders = new ArrayList<>();
        folders.add(DEFAULT_FOLDER);
        for (Bookmark b : all()) if (!folders.contains(b.folder)) folders.add(b.folder);
        return folders;
    }

    public String exportJson() {
        try {
            JSONArray arr = new JSONArray();
            for (Bookmark b : all()) {
                JSONObject o = new JSONObject();
                o.put("title", b.title);
                o.put("url", b.url);
                o.put("folder", b.folder);
                arr.put(o);
            }
            return arr.toString(2);
        } catch (Exception e) {
            return "[]";
        }
    }

    public int importJson(String json) {
        int added = 0;
        try {
            JSONArray arr = new JSONArray(json);
            List<Bookmark> list = all();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String url = o.optString("url", "");
                if (url.isEmpty()) continue;
                boolean dup = false;
                for (Bookmark b : list) if (b.url.equals(url)) { dup = true; break; }
                if (dup) continue;
                list.add(new Bookmark(o.optString("title", url), url, o.optString("folder", DEFAULT_FOLDER)));
                added++;
            }
            saveAll(list);
        } catch (Exception ignored) {}
        return added;
    }
}
