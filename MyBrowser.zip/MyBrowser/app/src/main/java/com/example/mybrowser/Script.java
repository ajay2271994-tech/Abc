package com.example.mybrowser;

import org.json.JSONException;
import org.json.JSONObject;

/** A single saved Site Script. */
public class Script {
    public static final String MODE_ALWAYS = "ALWAYS";
    public static final String MODE_MANUAL = "MANUAL";

    public String id;
    public String domain;   // "*" means all sites
    public String code;
    public boolean enabled = true;
    public String mode = MODE_MANUAL;

    public Script() {}

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("domain", domain);
        o.put("code", code);
        o.put("enabled", enabled);
        o.put("mode", mode);
        return o;
    }

    public static Script fromJson(JSONObject o) throws JSONException {
        Script s = new Script();
        s.id = o.optString("id", "");
        s.domain = o.optString("domain", "");
        s.code = o.optString("code", "");
        s.enabled = o.optBoolean("enabled", true);
        s.mode = o.optString("mode", MODE_MANUAL);
        return s;
    }

    public boolean matches(String host) {
        if (domain.equals("*")) return true;
        if (host == null) return false;
        return host.equals(domain) || host.endsWith("." + domain);
    }
}
