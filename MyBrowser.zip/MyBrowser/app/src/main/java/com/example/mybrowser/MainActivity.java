package com.example.mybrowser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.*;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final String DEFAULT_HOMEPAGE = "about:newtab"; // speed-dial start page

    // ---- premium color palette (set at startup; changes with Dark Mode) ----
    int COLOR_PRIMARY_DARK, COLOR_PRIMARY_LIGHT, COLOR_ACCENT, COLOR_TAB_ACTIVE, COLOR_TAB_INACTIVE, COLOR_BG, COLOR_ADDRESS_BG, COLOR_ADDRESS_TEXT, COLOR_TAB_ACTIVE_TEXT;

    void initColors() {
        boolean dark = cfg.getBoolean("dark_mode", false);
        if (dark) {
            COLOR_PRIMARY_DARK = Color.parseColor("#1A1333");
            COLOR_PRIMARY_LIGHT = Color.parseColor("#2E2060");
            COLOR_ACCENT = Color.parseColor("#00D2B4");
            COLOR_TAB_ACTIVE = Color.parseColor("#3A2F6B");
            COLOR_TAB_INACTIVE = Color.parseColor("#241A47");
            COLOR_BG = Color.parseColor("#121018");
            COLOR_ADDRESS_BG = Color.parseColor("#2A2140");
            COLOR_ADDRESS_TEXT = Color.WHITE;
            COLOR_TAB_ACTIVE_TEXT = Color.WHITE;
        } else {
            COLOR_PRIMARY_DARK = Color.parseColor("#3B2A9E");
            COLOR_PRIMARY_LIGHT = Color.parseColor("#7B5CF0");
            COLOR_ACCENT = Color.parseColor("#00D2B4");
            COLOR_TAB_ACTIVE = Color.parseColor("#FFFFFF");
            COLOR_TAB_INACTIVE = Color.parseColor("#5B46C0");
            COLOR_BG = Color.parseColor("#F5F6FA");
            COLOR_ADDRESS_BG = Color.WHITE;
            COLOR_ADDRESS_TEXT = COLOR_PRIMARY_DARK;
            COLOR_TAB_ACTIVE_TEXT = COLOR_PRIMARY_DARK;
        }
    }

    static final String DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

    // ---- tabs ----
    List<WebView> tabs = new ArrayList<>();
    int currentTabIndex = 0;
    WebView web; // the currently active tab's WebView
    BrowserGestureContainer webViewContainer;
    TextView pullIndicator;
    LinearLayout tabStrip;

    EditText urlBar;
    TextView addressDisplay;
    LinearLayout suggestionsPanel;
    Button starBtn;
    FrameLayout content;
    Button runScriptFab;
    ValueCallback<Uri[]> fileCb;

    LinearLayout findBar;
    EditText findInput;

    SharedPreferences cfg;      // app-level config: master on/off, pin, homepage
    LicenseManager lm;
    ScriptStore scripts;
    BookmarkStore bookmarks;
    HistoryStore history;
    ReadingListStore readingList;

    java.util.Set<WebView> forceDarkTabs = new java.util.HashSet<>();
    static final int REQ_EXPORT_BOOKMARKS = 101, REQ_IMPORT_BOOKMARKS = 102, REQ_EXPORT_SCRIPTS = 103, REQ_IMPORT_SCRIPTS = 104;

    static final String[] AD_BLOCKLIST = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adsystem.com", "amazon-adsystem.com", "facebook.com/tr", "analytics.google.com",
        "google-analytics.com", "scorecardresearch.com", "outbrain.com", "taboola.com",
        "popads.net", "pubmatic.com", "adnxs.com", "criteo.com"
    };

    View scrim;
    LinearLayout bookmarksPanel;
    LinearLayout bookmarksListContainer;

    ProgressBar progressBar;
    java.util.Set<WebView> incognitoTabs = new java.util.HashSet<>();
    List<String[]> recentlyClosed = new ArrayList<>(); // {title, url}
    List<String> consoleLogs = new ArrayList<>();
    SharedPreferences jsPerSite; // domain -> "off" means JS disabled for that site

    static final int REQ_FILE = 1, REQ_PERM = 2;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        cfg = getSharedPreferences("app_config", MODE_PRIVATE);
        jsPerSite = getSharedPreferences("js_per_site", MODE_PRIVATE);
        initColors();
        lm = new LicenseManager(this);
        scripts = new ScriptStore(this);
        bookmarks = new BookmarkStore(this);
        history = new HistoryStore(this);
        readingList = new ReadingListStore(this);
        lm.checkLicense(null); // background refresh, never blocks startup

        requestPermissions(new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO}, REQ_PERM);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // ---- tab strip (colorful) ----
        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setBackgroundColor(COLOR_PRIMARY_DARK);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabStrip.setPadding(8, 6, 8, 6);
        tabScroll.addView(tabStrip);
        root.addView(tabScroll, new LinearLayout.LayoutParams(-1, -2));

        // ---- top bar: Reload, address pill (tap to edit), star, three-dot menu ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackground(gradientBg(COLOR_PRIMARY_LIGHT, COLOR_PRIMARY_DARK));
        bar.setPadding(12, 10, 12, 10);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setElevation(8);

        Button reloadBtn = navButton("\u21BB");
        reloadBtn.setOnClickListener(v -> web.reload());

        // address pill: a container that swaps between a title display and an editable URL field
        FrameLayout addressWrap = new FrameLayout(this);
        addressWrap.setBackground(pillBg(COLOR_ADDRESS_BG));

        addressDisplay = new TextView(this);
        addressDisplay.setText("New Tab");
        addressDisplay.setSingleLine(true);
        addressDisplay.setTextColor(COLOR_ADDRESS_TEXT);
        addressDisplay.setPadding(32, 20, 32, 20);
        addressDisplay.setOnClickListener(v -> showUrlEditor());

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Search or enter address");
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setBackgroundColor(Color.TRANSPARENT);
        urlBar.setTextColor(COLOR_ADDRESS_TEXT);
        urlBar.setPadding(32, 16, 32, 16);
        urlBar.setVisibility(View.GONE);

        addressWrap.addView(addressDisplay, new FrameLayout.LayoutParams(-1, -2));
        addressWrap.addView(urlBar, new FrameLayout.LayoutParams(-1, -2));

        starBtn = navButton("\u2606");
        starBtn.setOnClickListener(v -> toggleBookmarkCurrentPage());

        Button menuBtn = navButton("\u22EE");
        menuBtn.setOnClickListener(this::showMainMenu);

        bar.addView(reloadBtn, new LinearLayout.LayoutParams(-2, -2));
        bar.addView(addressWrap, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(starBtn, new LinearLayout.LayoutParams(-2, -2));
        bar.addView(menuBtn, new LinearLayout.LayoutParams(-2, -2));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        // ---- address suggestions (bookmarks + history), shown only while editing ----
        suggestionsPanel = new LinearLayout(this);
        suggestionsPanel.setOrientation(LinearLayout.VERTICAL);
        suggestionsPanel.setBackgroundColor(COLOR_ADDRESS_BG);
        suggestionsPanel.setVisibility(View.GONE);
        root.addView(suggestionsPanel, new LinearLayout.LayoutParams(-1, -2));

        urlBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { updateSuggestions(s.toString()); }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        // ---- find-in-page bar (hidden by default) ----
        findBar = new LinearLayout(this);
        findBar.setOrientation(LinearLayout.HORIZONTAL);
        findBar.setVisibility(View.GONE);
        findBar.setPadding(8, 4, 8, 4);
        findInput = new EditText(this);
        findInput.setHint("Find in page");
        findInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        findInput.setOnEditorActionListener((v, id, e) -> { web.findAllAsync(findInput.getText().toString()); return true; });
        Button findNext = new Button(this); findNext.setText("\u2193");
        findNext.setOnClickListener(v -> web.findNext(true));
        Button findPrev = new Button(this); findPrev.setText("\u2191");
        findPrev.setOnClickListener(v -> web.findNext(false));
        Button findClose = new Button(this); findClose.setText("\u2715");
        findClose.setOnClickListener(v -> { web.clearMatches(); findInput.setText(""); findBar.setVisibility(View.GONE); });
        findBar.addView(findInput, new LinearLayout.LayoutParams(0, -2, 1f));
        findBar.addView(findPrev, new LinearLayout.LayoutParams(-2, -2));
        findBar.addView(findNext, new LinearLayout.LayoutParams(-2, -2));
        findBar.addView(findClose, new LinearLayout.LayoutParams(-2, -2));
        root.addView(findBar, new LinearLayout.LayoutParams(-1, -2));

        // ---- page load progress bar ----
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, 8));

        // ---- content area: tab WebViews + floating Run Script button + bookmarks sidebar ----
        content = new FrameLayout(this);

        webViewContainer = new BrowserGestureContainer(this);
        webViewContainer.setListener(new BrowserGestureContainer.Listener() {
            @Override public WebView currentWebView() { return web; }
            @Override public void onPullToRefresh() {
                pullIndicator.setVisibility(View.GONE);
                if (web != null) web.reload();
            }
            @Override public void onEdgeSwipeBack() { if (web != null && web.canGoBack()) web.goBack(); }
            @Override public void onEdgeSwipeForward() { if (web != null && web.canGoForward()) web.goForward(); }
            @Override public void onPullProgress(float progress) {
                pullIndicator.setVisibility(View.VISIBLE);
                pullIndicator.setText(progress >= 1f ? "↓ Release to refresh" : "↓ Pull to refresh");
            }
            @Override public void onPullCancelled() { pullIndicator.setVisibility(View.GONE); }
        });
        content.addView(webViewContainer, new FrameLayout.LayoutParams(-1, -1));

        pullIndicator = new TextView(this);
        pullIndicator.setText("↓ Pull to refresh");
        pullIndicator.setBackground(pillBg(COLOR_PRIMARY_DARK));
        pullIndicator.setTextColor(Color.WHITE);
        pullIndicator.setPadding(24, 10, 24, 10);
        pullIndicator.setVisibility(View.GONE);
        FrameLayout.LayoutParams pullLp = new FrameLayout.LayoutParams(-2, -2);
        pullLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        pullLp.setMargins(0, 16, 0, 0);
        content.addView(pullIndicator, pullLp);

        runScriptFab = new Button(this);
        runScriptFab.setText("\u25B6 Run Script");
        runScriptFab.setTextColor(Color.WHITE);
        runScriptFab.setBackground(pillBg(COLOR_ACCENT));
        runScriptFab.setPadding(40, 24, 40, 24);
        runScriptFab.setElevation(12);
        runScriptFab.setVisibility(View.GONE);
        runScriptFab.setOnClickListener(v -> onRunScriptTapped());
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(-2, -2);
        fabLp.gravity = Gravity.BOTTOM | Gravity.END;
        fabLp.setMargins(0, 0, 32, 32);
        content.addView(runScriptFab, fabLp);

        // left sidebar: Bookmarks
        scrim = new View(this);
        scrim.setBackgroundColor(Color.parseColor("#80000000"));
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeBookmarksPanel());
        content.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        bookmarksPanel = new LinearLayout(this);
        bookmarksPanel.setOrientation(LinearLayout.VERTICAL);
        bookmarksPanel.setBackgroundColor(Color.WHITE);
        bookmarksPanel.setVisibility(View.GONE);
        bookmarksPanel.setPadding(24, 24, 24, 24);

        TextView panelTitle = new TextView(this);
        panelTitle.setText("Bookmarks");
        panelTitle.setTextSize(18);
        panelTitle.setPadding(0, 0, 0, 16);
        bookmarksPanel.addView(panelTitle);

        bookmarksListContainer = new LinearLayout(this);
        bookmarksListContainer.setOrientation(LinearLayout.VERTICAL);
        ScrollView panelScroll = new ScrollView(this);
        panelScroll.addView(bookmarksListContainer);
        bookmarksPanel.addView(panelScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        Button closePanelBtn = new Button(this);
        closePanelBtn.setText("Close");
        closePanelBtn.setOnClickListener(v -> closeBookmarksPanel());
        bookmarksPanel.addView(closePanelBtn);

        int panelWidth = (int) (280 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(panelWidth, -1);
        panelLp.gravity = Gravity.START;
        content.addView(bookmarksPanel, panelLp);

        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.setBackgroundColor(COLOR_BG);
        setContentView(root);

        createTab(homepage());
    }

    Button navButton(String label) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(Color.TRANSPARENT);
        btn.setPadding(16, 8, 16, 8);
        return btn;
    }

    android.graphics.drawable.GradientDrawable pillBg(int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(100f);
        return d;
    }

    android.graphics.drawable.GradientDrawable gradientBg(int colorStart, int colorEnd) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{colorStart, colorEnd});
        return d;
    }

    void showUrlEditor() {
        addressDisplay.setVisibility(View.GONE);
        urlBar.setVisibility(View.VISIBLE);
        String cur = String.valueOf(web.getUrl());
        urlBar.setText((cur.equals("null") || cur.equals("about:newtab")) ? "" : cur);
        urlBar.requestFocus();
        urlBar.selectAll();
        android.view.inputmethod.InputMethodManager imm =
            (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(urlBar, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
        updateSuggestions("");
    }

    void hideUrlEditor() {
        urlBar.setVisibility(View.GONE);
        addressDisplay.setVisibility(View.VISIBLE);
        suggestionsPanel.setVisibility(View.GONE);
        android.view.inputmethod.InputMethodManager imm =
            (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    void updateSuggestions(String typed) {
        suggestionsPanel.removeAllViews();
        String q = typed.trim().toLowerCase();
        if (q.isEmpty()) { suggestionsPanel.setVisibility(View.GONE); return; }

        List<String[]> matches = new ArrayList<>(); // {title, url}
        for (BookmarkStore.Bookmark b : bookmarks.all()) {
            if (b.title.toLowerCase().contains(q) || b.url.toLowerCase().contains(q)) matches.add(new String[]{b.title, b.url});
            if (matches.size() >= 5) break;
        }
        if (matches.size() < 5) {
            for (HistoryStore.Entry h : history.all()) {
                if (h.title.toLowerCase().contains(q) || h.url.toLowerCase().contains(q)) matches.add(new String[]{h.title, h.url});
                if (matches.size() >= 5) break;
            }
        }
        if (matches.isEmpty()) { suggestionsPanel.setVisibility(View.GONE); return; }

        for (String[] m : matches) {
            TextView row = new TextView(this);
            row.setText(m[0] + "\n" + m[1]);
            row.setTextSize(12);
            row.setTextColor(COLOR_ADDRESS_TEXT);
            row.setPadding(32, 16, 32, 16);
            row.setOnClickListener(v -> { load(m[1]); hideUrlEditor(); });
            suggestionsPanel.addView(row);
        }
        suggestionsPanel.setVisibility(View.VISIBLE);
    }

    void updateAddressDisplay() {
        if (addressDisplay == null || web == null) return;
        String url = String.valueOf(web.getUrl());
        if (url.equals("about:newtab")) { addressDisplay.setText("New Tab"); return; }
        String title = web.getTitle();
        String shown;
        if (title != null && !title.isEmpty()) shown = title;
        else if (!url.equals("null") && !url.isEmpty()) shown = hostOf(url).isEmpty() ? url : hostOf(url);
        else shown = "New Tab";
        addressDisplay.setText(shown);
    }

    // ================= TABS =================

    void configureWebView(WebView wv) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // render pages the way a PC browser would lay them out, and allow pinch-zoom
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setBlockNetworkImage(cfg.getBoolean("data_saver", false));

        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap f) {
                applyPerSiteJsSetting(v, url);
                if (v == web) {
                    addressDisplay.setText(url.equals("about:newtab") ? "New Tab" :
                        (isSecure(url) ? "\uD83D\uDD12 " : "") + (hostOf(url).isEmpty() ? url : hostOf(url)));
                    runScriptFab.setVisibility(View.GONE);
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(0);
                }
                updateTabChip(v);
            }
            @Override public void onPageFinished(WebView v, String url) {
                String host = hostOf(url);
                runAlwaysScripts(v, host);
                if (!incognitoTabs.contains(v) && !url.equals("about:newtab")) history.add(v.getTitle(), url);
                if (forceDarkTabs.contains(v)) applyForceDarkJs(v);
                updateTabChip(v);
                if (v == web) {
                    updateRunScriptFab(host);
                    updateStarIcon();
                    updateAddressDisplay();
                    progressBar.setVisibility(View.GONE);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest request) {
                return false; // let this WebView keep handling navigation (incl. target=_blank same-tab)
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, android.webkit.WebResourceRequest request) {
                if (cfg.getBoolean("ad_block", true)) {
                    String reqHost = request.getUrl().getHost();
                    if (reqHost != null && isAdHost(reqHost)) {
                        return new WebResourceResponse("text/plain", "utf-8", new java.io.ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(v, request);
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(
                    String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, true, false);
            }
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> r.grant(r.getResources()));
            }
            @Override public boolean onShowFileChooser(WebView w,
                    ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
            @Override public void onProgressChanged(WebView v, int newProgress) {
                if (v == web) progressBar.setProgress(newProgress);
            }
            @Override public boolean onConsoleMessage(ConsoleMessage cm) {
                consoleLogs.add(0, "[" + cm.messageLevel() + "] " + cm.message() + "  (line " + cm.lineNumber() + ")");
                while (consoleLogs.size() > 200) consoleLogs.remove(consoleLogs.size() - 1);
                return true;
            }
        });

        wv.setOnLongClickListener(v -> {
            WebView.HitTestResult result = wv.getHitTestResult();
            if (result == null) return false;
            int type = result.getType();
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                String linkUrl = result.getExtra();
                if (linkUrl == null) return false;
                showLinkContextMenu(linkUrl);
                return true;
            }
            return false;
        });

        wv.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                android.app.DownloadManager.Request request = new android.app.DownloadManager.Request(Uri.parse(downloadUrl));
                request.setMimeType(mimetype);
                String cookie = CookieManager.getInstance().getCookie(downloadUrl);
                if (cookie != null) request.addRequestHeader("cookie", cookie);
                request.addRequestHeader("User-Agent", userAgent);
                String filename = android.webkit.URLUtil.guessFileName(downloadUrl, contentDisposition, mimetype);
                request.setTitle(filename);
                request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, filename);
                android.app.DownloadManager dm = (android.app.DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(request);
                Toast.makeText(this, "Downloading " + filename, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Could not start download.", Toast.LENGTH_SHORT).show();
            }
        });

        urlBar.setOnEditorActionListener((v, id, e) -> {
            load(urlBar.getText().toString());
            hideUrlEditor();
            return true;
        });
    }

    void createTab(String url) {
        WebView wv = new WebView(this);
        configureWebView(wv);
        webViewContainer.addView(wv, new FrameLayout.LayoutParams(-1, -1));
        tabs.add(wv);
        switchTab(tabs.size() - 1);
        rebuildTabStrip();
        load(url);
    }

    void switchTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        currentTabIndex = index;
        web = tabs.get(index);
        for (int i = 0; i < tabs.size(); i++) tabs.get(i).setVisibility(i == index ? View.VISIBLE : View.GONE);
        hideUrlEditor();
        updateAddressDisplay();
        updateRunScriptFab(hostOf(String.valueOf(web.getUrl())));
        updateStarIcon();
        rebuildTabStrip();
    }

    void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        WebView wv = tabs.remove(index);
        if (!incognitoTabs.contains(wv)) {
            String u = String.valueOf(wv.getUrl());
            String t = wv.getTitle();
            if (!u.equals("null") && !u.isEmpty()) {
                recentlyClosed.add(0, new String[]{(t == null || t.isEmpty()) ? u : t, u});
                while (recentlyClosed.size() > 10) recentlyClosed.remove(recentlyClosed.size() - 1);
            }
        }
        incognitoTabs.remove(wv);
        webViewContainer.removeView(wv);
        wv.destroy();
        if (tabs.isEmpty()) {
            createTab(homepage());
        } else {
            switchTab(Math.min(index, tabs.size() - 1));
        }
        rebuildTabStrip();
    }

    void showRecentlyClosedDialog() {
        if (recentlyClosed.isEmpty()) {
            Toast.makeText(this, "No recently closed tabs.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[recentlyClosed.size()];
        for (int i = 0; i < recentlyClosed.size(); i++) labels[i] = recentlyClosed.get(i)[0];
        new AlertDialog.Builder(this)
            .setTitle("Recently Closed Tabs")
            .setItems(labels, (d, i) -> createTab(recentlyClosed.get(i)[1]))
            .setNegativeButton("Close", null)
            .show();
    }

    // ---- Private / Incognito tab (no history saved; cookies cleared on close) ----

    void createIncognitoTab() {
        WebView wv = new WebView(this);
        configureWebView(wv);
        incognitoTabs.add(wv);
        wv.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        wv.getSettings().setSaveFormData(false);
        webViewContainer.addView(wv, new FrameLayout.LayoutParams(-1, -1));
        tabs.add(wv);
        switchTab(tabs.size() - 1);
        rebuildTabStrip();
        load(homepage());
        Toast.makeText(this, "Private tab: history for this tab won't be saved. Note: cookies are shared with other tabs until this tab is closed (WebView limitation).", Toast.LENGTH_LONG).show();
    }

    // ---- Dark mode ----

    void toggleDarkMode() {
        boolean newVal = !cfg.getBoolean("dark_mode", false);
        cfg.edit().putBoolean("dark_mode", newVal).apply();
        recreate();
    }

    // ---- HTTPS indicator ----

    boolean isSecure(String url) {
        return url != null && url.startsWith("https://");
    }

    // ---- long-press link menu ----

    void showLinkContextMenu(String linkUrl) {
        new AlertDialog.Builder(this)
            .setTitle(linkUrl)
            .setItems(new String[]{"Open in New Tab", "Copy Link", "Share Link"}, (d, which) -> {
                switch (which) {
                    case 0: createTab(linkUrl); break;
                    case 1: {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("link", linkUrl));
                        Toast.makeText(this, "Link copied.", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case 2: {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                        send.putExtra(Intent.EXTRA_TEXT, linkUrl);
                        startActivity(Intent.createChooser(send, "Share link via"));
                        break;
                    }
                }
            })
            .show();
    }

    // ---- per-site JavaScript toggle ----

    void applyPerSiteJsSetting(WebView wv, String url) {
        String host = hostOf(url);
        boolean jsOff = jsPerSite.getBoolean(host, false);
        wv.getSettings().setJavaScriptEnabled(!jsOff);
    }

    void toggleJsForCurrentSite() {
        String host = hostOf(String.valueOf(web.getUrl()));
        if (host.isEmpty()) { Toast.makeText(this, "Open a website first.", Toast.LENGTH_SHORT).show(); return; }
        boolean currentlyOff = jsPerSite.getBoolean(host, false);
        jsPerSite.edit().putBoolean(host, !currentlyOff).apply();
        Toast.makeText(this, (!currentlyOff ? "JavaScript turned OFF for " : "JavaScript turned ON for ") + host, Toast.LENGTH_SHORT).show();
        web.reload();
    }

    void updateTabChip(WebView v) {
        int idx = tabs.indexOf(v);
        if (idx >= 0) rebuildTabStrip();
    }

    void rebuildTabStrip() {
        tabStrip.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            WebView wv = tabs.get(i);
            String title = wv.getTitle();
            if (title == null || title.isEmpty()) title = "New Tab";
            if (title.length() > 14) title = title.substring(0, 14) + "\u2026";

            boolean active = idx == currentTabIndex;
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(20, 12, 10, 12);
            chip.setBackground(pillBg(active ? COLOR_TAB_ACTIVE : COLOR_TAB_INACTIVE));

            TextView label = new TextView(this);
            label.setText(title);
            label.setTextSize(12);
            label.setTextColor(active ? COLOR_TAB_ACTIVE_TEXT : Color.WHITE);
            chip.setOnClickListener(v -> switchTab(idx));

            Button closeBtn = new Button(this);
            closeBtn.setText("\u2715");
            closeBtn.setTextSize(10);
            closeBtn.setTextColor(active ? COLOR_TAB_ACTIVE_TEXT : Color.WHITE);
            closeBtn.setPadding(8, 0, 0, 0);
            closeBtn.setBackgroundColor(Color.TRANSPARENT);
            closeBtn.setOnClickListener(v -> closeTab(idx));

            chip.addView(label);
            chip.addView(closeBtn);
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(-2, -2);
            chipLp.setMargins(2, 0, 2, 0);
            tabStrip.addView(chip, chipLp);
        }

        Button addTab = new Button(this);
        addTab.setText("+");
        addTab.setTextColor(Color.WHITE);
        addTab.setBackgroundColor(Color.TRANSPARENT);
        addTab.setOnClickListener(v -> createTab(homepage()));
        tabStrip.addView(addTab);
    }

    // ================= DESKTOP SITE =================

    boolean isDesktopSite(WebView wv) {
        String ua = wv.getSettings().getUserAgentString();
        return ua != null && ua.equals(DESKTOP_UA);
    }

    void toggleDesktopSite() {
        WebSettings s = web.getSettings();
        if (isDesktopSite(web)) {
            s.setUserAgentString(null); // reset to system default (mobile)
            Toast.makeText(this, "Mobile site", Toast.LENGTH_SHORT).show();
        } else {
            s.setUserAgentString(DESKTOP_UA);
            Toast.makeText(this, "Desktop site", Toast.LENGTH_SHORT).show();
        }
        web.reload();
    }

    // ================= DATA SAVER / AD BLOCK =================

    void applyDataSaverToAllTabs() {
        boolean saver = cfg.getBoolean("data_saver", false);
        for (WebView wv : tabs) {
            wv.getSettings().setBlockNetworkImage(saver);
            wv.getSettings().setLoadsImagesAutomatically(!saver);
        }
    }

    boolean isAdHost(String host) {
        String h = host.toLowerCase();
        for (String blocked : AD_BLOCKLIST) if (h.equals(blocked) || h.endsWith("." + blocked)) return true;
        return false;
    }

    // ================= READER MODE (one-shot page simplification) =================

    void applyReaderMode() {
        // Reader Mode is a free browser feature (not license-gated like Site Scripts).
        String js = "(function(){" +
            "var sels=['nav','header','footer','aside','.ad','.ads','.advertisement','.sidebar','.cookie','.popup','.modal','.newsletter'];" +
            "sels.forEach(function(s){document.querySelectorAll(s).forEach(function(e){e.style.display='none';});});" +
            "document.body.style.maxWidth='700px';document.body.style.margin='0 auto';" +
            "document.body.style.fontSize='19px';document.body.style.lineHeight='1.7';" +
            "document.body.style.fontFamily='serif';document.body.style.padding='16px';" +
            "})();";
        web.evaluateJavascript(js, null);
        Toast.makeText(this, "Simplified this page for reading.", Toast.LENGTH_SHORT).show();
    }

    // ================= FORCE DARK (per-page content, not the app UI) =================

    void applyForceDarkJs(WebView wv) {
        wv.evaluateJavascript(
            "document.documentElement.style.filter='invert(1) hue-rotate(180deg)';" +
            "document.querySelectorAll('img,video,picture,svg').forEach(function(e){e.style.filter='invert(1) hue-rotate(180deg)';});",
            null);
    }

    void toggleForceDark() {
        if (forceDarkTabs.contains(web)) {
            web.evaluateJavascript("document.documentElement.style.filter='';document.querySelectorAll('img,video,picture,svg').forEach(function(e){e.style.filter='';});", null);
            forceDarkTabs.remove(web);
            Toast.makeText(this, "Force Dark turned off for this page.", Toast.LENGTH_SHORT).show();
        } else {
            applyForceDarkJs(web);
            forceDarkTabs.add(web);
            Toast.makeText(this, "Force Dark turned on for this page.", Toast.LENGTH_SHORT).show();
        }
    }

    // ================= SAVE AS PDF =================

    void printCurrentPage() {
        android.print.PrintManager printManager = (android.print.PrintManager) getSystemService(PRINT_SERVICE);
        String jobName = "Page";
        android.print.PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(jobName);
        printManager.print(jobName, adapter, new android.print.PrintAttributes.Builder().build());
    }

    // ================= COPY ALL LINKS =================

    void copyAllLinks() {
        web.evaluateJavascript("JSON.stringify(Array.from(document.querySelectorAll('a')).map(function(a){return a.href;}))", result -> {
            String links;
            try {
                org.json.JSONArray arr = new org.json.JSONArray(new org.json.JSONTokener(result).nextValue().toString());
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < arr.length(); i++) sb.append(arr.getString(i)).append("\n");
                links = sb.toString();
            } catch (Exception e) {
                links = "";
            }
            final String finalLinks = links;
            TextView tv = new TextView(this);
            tv.setText(finalLinks.isEmpty() ? "No links found on this page." : finalLinks);
            tv.setTextIsSelectable(true);
            tv.setPadding(40, 30, 40, 30);
            ScrollView sv = new ScrollView(this);
            sv.addView(tv);
            new AlertDialog.Builder(this).setTitle("All Links").setView(sv)
                .setPositiveButton("Copy All", (d, w) -> {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("links", finalLinks));
                    Toast.makeText(this, "Copied.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Close", null).show();
        });
    }

    // ================= SCREENSHOT =================

    void takeScreenshot() {
        try {
            Bitmap bmp = Bitmap.createBitmap(Math.max(1, web.getWidth()), Math.max(1, web.getHeight()), Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas = new android.graphics.Canvas(bmp);
            web.draw(canvas);
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "screenshot_" + System.currentTimeMillis() + ".png");
            values.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png");
            Uri uri = getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
                if (os != null) os.close();
                Toast.makeText(this, "Screenshot saved to gallery.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Could not save screenshot.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not save screenshot.", Toast.LENGTH_SHORT).show();
        }
    }

    // ================= READING LIST =================

    void addToReadingList() {
        String url = String.valueOf(web.getUrl());
        if (url.equals("null") || url.isEmpty() || url.equals("about:newtab")) {
            Toast.makeText(this, "Open a website first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (readingList.contains(url)) {
            Toast.makeText(this, "Already in your Reading List.", Toast.LENGTH_SHORT).show();
            return;
        }
        String title = web.getTitle();
        readingList.add((title == null || title.isEmpty()) ? url : title, url);
        Toast.makeText(this, "Added to Reading List.", Toast.LENGTH_SHORT).show();
    }

    void showReadingListDialog() {
        List<ReadingListStore.Item> list = readingList.all();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30, 20, 30, 0);

        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Your Reading List is empty. Use \"Add to Reading List\" from the menu.");
            l.addView(empty);
        } else {
            for (ReadingListStore.Item it : list) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, 12, 0, 12);

                TextView label = new TextView(this);
                label.setText((it.read ? "\u2713 " : "") + it.title);
                label.setOnClickListener(v -> { readingList.markRead(it.url, true); load(it.url); });

                Button removeBtn = new Button(this);
                removeBtn.setText("\u2715");
                removeBtn.setOnClickListener(v -> { readingList.remove(it.url); showReadingListDialog(); });

                row.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(removeBtn, new LinearLayout.LayoutParams(-2, -2));
                l.addView(row);
            }
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("Reading List").setView(sv).setPositiveButton("Close", null).show();
    }

    // ================= EXPORT / IMPORT (bookmarks + site scripts) =================

    void exportBookmarks() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "bookmarks_backup.json");
        startActivityForResult(intent, REQ_EXPORT_BOOKMARKS);
    }

    void importBookmarks() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_IMPORT_BOOKMARKS);
    }

    void exportScripts() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "site_scripts_backup.json");
        startActivityForResult(intent, REQ_EXPORT_SCRIPTS);
    }

    void importScripts() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_IMPORT_SCRIPTS);
    }

    void writeTextToUri(Uri uri, String text) throws Exception {
        try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
            os.write(text.getBytes("UTF-8"));
        }
    }

    String readTextFromUri(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (java.io.InputStream is = getContentResolver().openInputStream(uri);
             java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
        }
        return sb.toString();
    }

    // ================= MASTER ON/OFF LOCK (local, PIN-protected) =================

    boolean featureEnabled() {
        return cfg.getBoolean("js_feature_enabled", true);
    }

    void showLockDialog() {
        if (!cfg.contains("pin")) {
            final EditText p1 = new EditText(this);
            p1.setHint("Create a PIN");
            p1.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            new AlertDialog.Builder(this)
                .setTitle("Set a PIN")
                .setMessage("This PIN will be required to turn the Site Script feature on or off.")
                .setView(p1)
                .setPositiveButton("Set", (d, w) -> {
                    String pin = p1.getText().toString().trim();
                    if (pin.isEmpty()) return;
                    cfg.edit().putString("pin", pin).apply();
                    Toast.makeText(this, "PIN set.", Toast.LENGTH_SHORT).show();
                    showLockDialog();
                })
                .show();
            return;
        }

        final EditText pinEntry = new EditText(this);
        pinEntry.setHint("Enter PIN");
        pinEntry.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
            .setTitle(featureEnabled() ? "Turn off Site Script feature?" : "Turn on Site Script feature?")
            .setView(pinEntry)
            .setPositiveButton(featureEnabled() ? "Turn off" : "Turn on", (d, w) -> {
                String entered = pinEntry.getText().toString().trim();
                String real = cfg.getString("pin", "");
                if (!entered.equals(real)) {
                    Toast.makeText(this, "Incorrect PIN.", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean newState = !featureEnabled();
                cfg.edit().putBoolean("js_feature_enabled", newState).apply();
                Toast.makeText(this, newState ? "Site Script feature turned on." : "Site Script feature turned off.", Toast.LENGTH_SHORT).show();
                if (!newState) { runScriptFab.setVisibility(View.GONE); web.reload(); }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ================= THREE-DOT MENU =================

    void showMainMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "New Tab");
        pm.getMenu().add(0, 2, 0, "Forward");
        pm.getMenu().add(0, 3, 0, "Bookmarks");
        pm.getMenu().add(0, 4, 0, "History");
        pm.getMenu().add(0, 5, 0, "Find in Page");
        pm.getMenu().add(0, 6, 0, isDesktopSite(web) ? "\u2713 Desktop Site" : "Desktop Site");
        pm.getMenu().add(0, 7, 0, "Share");
        pm.getMenu().add(0, 8, 0, "DevTools");
        pm.getMenu().add(0, 9, 0, "Settings");
        pm.getMenu().add(0, 10, 0, "New Private Tab");
        pm.getMenu().add(0, 11, 0, "Recently Closed Tabs");
        pm.getMenu().add(0, 12, 0, cfg.getBoolean("dark_mode", false) ? "\u2713 Dark Mode" : "Dark Mode");
        pm.getMenu().add(0, 13, 0, "Reader Mode");
        pm.getMenu().add(0, 14, 0, forceDarkTabs.contains(web) ? "\u2713 Force Dark (this page)" : "Force Dark (this page)");
        pm.getMenu().add(0, 15, 0, "Save as PDF");
        pm.getMenu().add(0, 16, 0, "Add to Reading List");
        pm.getMenu().add(0, 17, 0, "Reading List");
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: createTab(homepage()); return true;
                case 2: if (web.canGoForward()) web.goForward(); else Toast.makeText(this, "No forward history.", Toast.LENGTH_SHORT).show(); return true;
                case 3: openBookmarksPanel(); return true;
                case 4: showHistoryDialog(); return true;
                case 5: openFindBar(); return true;
                case 6: toggleDesktopSite(); return true;
                case 7: shareCurrentPage(); return true;
                case 13: applyReaderMode(); return true;
                case 14: toggleForceDark(); return true;
                case 15: printCurrentPage(); return true;
                case 16: addToReadingList(); return true;
                case 17: showReadingListDialog(); return true;
                case 8: showDevToolsDialog(); return true;
                case 9: showSettingsDialog(); return true;
                case 10: createIncognitoTab(); return true;
                case 11: showRecentlyClosedDialog(); return true;
                case 12: toggleDarkMode(); return true;
            }
            return false;
        });
        pm.show();
    }

    void openFindBar() {
        findBar.setVisibility(View.VISIBLE);
        findInput.requestFocus();
    }

    void shareCurrentPage() {
        String url = String.valueOf(web.getUrl());
        if (url == null || url.equals("null")) return;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(send, "Share via"));
    }

    // ================= DEVTOOLS =================

    void showDevToolsDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30, 20, 30, 0);

        TextView heading = new TextView(this);
        heading.setText("Developer tools for the current page.");
        heading.setPadding(0, 0, 0, 16);
        l.addView(heading);

        Button scriptsBtn = new Button(this);
        scriptsBtn.setText("Site Scripts (Premium)");
        scriptsBtn.setOnClickListener(v -> showScriptListDialog());
        l.addView(scriptsBtn);

        Button sourceBtn = new Button(this);
        sourceBtn.setText("View Page Source");
        sourceBtn.setOnClickListener(v -> viewPageSource());
        l.addView(sourceBtn);

        Button consoleBtn = new Button(this);
        consoleBtn.setText("Run JavaScript Now (Console)");
        consoleBtn.setOnClickListener(v -> showQuickConsoleDialog());
        l.addView(consoleBtn);

        Button lockBtn = new Button(this);
        lockBtn.setText("Lock / Unlock Site Script Feature (PIN)");
        lockBtn.setOnClickListener(v -> showLockDialog());
        l.addView(lockBtn);

        TextView divider = new TextView(this);
        divider.setText("\nInspection");
        l.addView(divider);

        Button consoleLogBtn = new Button(this);
        consoleLogBtn.setText("Console Log");
        consoleLogBtn.setOnClickListener(v -> showConsoleLogDialog());
        l.addView(consoleLogBtn);

        Button cookiesBtn = new Button(this);
        cookiesBtn.setText("Cookies for this Site");
        cookiesBtn.setOnClickListener(v -> showCookiesDialog());
        l.addView(cookiesBtn);

        Button storageBtn = new Button(this);
        storageBtn.setText("Local / Session Storage");
        storageBtn.setOnClickListener(v -> showStorageDialog());
        l.addView(storageBtn);

        Button viewportBtn = new Button(this);
        viewportBtn.setText("Viewport Info");
        viewportBtn.setOnClickListener(v -> showViewportInfo());
        l.addView(viewportBtn);

        Button jsToggleBtn = new Button(this);
        String host = hostOf(String.valueOf(web.getUrl()));
        boolean jsOff = jsPerSite.getBoolean(host, false);
        jsToggleBtn.setText(jsOff ? "JavaScript is OFF for this site (tap to enable)" : "JavaScript is ON for this site (tap to disable)");
        jsToggleBtn.setOnClickListener(v -> toggleJsForCurrentSite());
        l.addView(jsToggleBtn);

        Button clearSiteBtn = new Button(this);
        clearSiteBtn.setText("Clear Data for this Site");
        clearSiteBtn.setOnClickListener(v -> clearCurrentSiteData());
        l.addView(clearSiteBtn);

        Button copyLinksBtn = new Button(this);
        copyLinksBtn.setText("Copy All Links on Page");
        copyLinksBtn.setOnClickListener(v -> copyAllLinks());
        l.addView(copyLinksBtn);

        Button screenshotBtn = new Button(this);
        screenshotBtn.setText("Take Screenshot");
        screenshotBtn.setOnClickListener(v -> takeScreenshot());
        l.addView(screenshotBtn);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("DevTools").setView(sv).setPositiveButton("Close", null).show();
    }

    void showConsoleLogDialog() {
        String text = consoleLogs.isEmpty() ? "No console messages captured yet." : String.join("\n\n", consoleLogs);
        showTextDialog("Console Log (most recent first)", text);
    }

    void showCookiesDialog() {
        String url = String.valueOf(web.getUrl());
        String cookies = CookieManager.getInstance().getCookie(url);
        showTextDialog("Cookies for " + hostOf(url), cookies == null || cookies.isEmpty() ? "No cookies for this site." : cookies.replace("; ", ";\n"));
    }

    void showStorageDialog() {
        web.evaluateJavascript("JSON.stringify(localStorage)", localResult ->
            web.evaluateJavascript("JSON.stringify(sessionStorage)", sessionResult -> {
                String text = "localStorage:\n" + localResult + "\n\nsessionStorage:\n" + sessionResult;
                showTextDialog("Storage for " + hostOf(String.valueOf(web.getUrl())), text);
            }));
    }

    void showViewportInfo() {
        web.evaluateJavascript(
            "JSON.stringify({width: window.innerWidth, height: window.innerHeight, dpr: window.devicePixelRatio, ua: navigator.userAgent})",
            result -> showTextDialog("Viewport Info", result));
    }

    void clearCurrentSiteData() {
        String url = String.valueOf(web.getUrl());
        String host = hostOf(url);
        if (host.isEmpty()) { Toast.makeText(this, "Open a website first.", Toast.LENGTH_SHORT).show(); return; }

        // clear this site's cookies (best-effort: WebView has no true per-site cookie API)
        String cookies = CookieManager.getInstance().getCookie(url);
        if (cookies != null) {
            for (String pair : cookies.split(";")) {
                String name = pair.split("=")[0].trim();
                if (!name.isEmpty()) {
                    CookieManager.getInstance().setCookie(url, name + "=; Max-Age=0; Path=/");
                }
            }
        }
        // localStorage/sessionStorage are per-origin, so this part IS precise
        String origin = Uri.parse(url).getScheme() + "://" + Uri.parse(url).getHost() +
            (Uri.parse(url).getPort() != -1 ? (":" + Uri.parse(url).getPort()) : "");
        WebStorage.getInstance().deleteOrigin(origin);

        web.reload();
        Toast.makeText(this, "Cleared cookies and storage for " + host + ".", Toast.LENGTH_SHORT).show();
    }

    void viewPageSource() {
        web.evaluateJavascript("document.documentElement.outerHTML", html -> {
            String unescaped = html;
            try {
                unescaped = new org.json.JSONTokener(html).nextValue().toString();
            } catch (Exception ignored) {}
            showTextDialog("Page Source", unescaped);
        });
    }

    void showQuickConsoleDialog() {
        if (!featureEnabled() || !lm.isSiteScriptAllowed()) {
            showLicenseRequiredDialog();
            return;
        }
        final EditText code = new EditText(this);
        code.setHint("JavaScript to run on this page right now");
        code.setMinLines(5);
        code.setGravity(Gravity.TOP);
        new AlertDialog.Builder(this)
            .setTitle("Run JavaScript Now")
            .setView(code)
            .setPositiveButton("Run", (d, w) -> {
                web.evaluateJavascript(code.getText().toString(), null);
                Toast.makeText(this, "Executed.", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ================= BOOKMARKS =================

    void updateStarIcon() {
        String url = String.valueOf(web.getUrl());
        starBtn.setText(bookmarks.isBookmarked(url) ? "\u2605" : "\u2606");
    }

    void toggleBookmarkCurrentPage() {
        String url = String.valueOf(web.getUrl());
        if (url == null || url.equals("null") || url.trim().isEmpty()) {
            Toast.makeText(this, "Open a website first before bookmarking it.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (bookmarks.isBookmarked(url)) {
            bookmarks.removeByUrl(url);
            Toast.makeText(this, "Bookmark removed.", Toast.LENGTH_SHORT).show();
        } else {
            String title = web.getTitle();
            bookmarks.add((title == null || title.isEmpty()) ? url : title, url);
            Toast.makeText(this, "Bookmark added.", Toast.LENGTH_SHORT).show();
        }
        updateStarIcon();
        refreshBookmarksPanel();
    }

    void openBookmarksPanel() {
        refreshBookmarksPanel();
        scrim.setVisibility(View.VISIBLE);
        bookmarksPanel.setVisibility(View.VISIBLE);
        scrim.bringToFront();
        bookmarksPanel.bringToFront();
    }

    void closeBookmarksPanel() {
        scrim.setVisibility(View.GONE);
        bookmarksPanel.setVisibility(View.GONE);
    }

    void refreshBookmarksPanel() {
        bookmarksListContainer.removeAllViews();
        List<BookmarkStore.Bookmark> list = bookmarks.all();
        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No bookmarks yet.\nTap the \u2606 star next to the address bar to add one.");
            bookmarksListContainer.addView(empty);
            return;
        }

        List<String> folders = bookmarks.allFolders();
        for (String folder : folders) {
            List<BookmarkStore.Bookmark> inFolder = new ArrayList<>();
            for (BookmarkStore.Bookmark b : list) if (b.folder.equals(folder)) inFolder.add(b);
            if (inFolder.isEmpty()) continue;

            TextView header = new TextView(this);
            header.setText(folder);
            header.setTextSize(12);
            header.setTextColor(COLOR_PRIMARY_LIGHT);
            header.setPadding(0, 20, 0, 6);
            bookmarksListContainer.addView(header);

            for (BookmarkStore.Bookmark bm : inFolder) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, 12, 0, 12);

                TextView label = new TextView(this);
                label.setText(bm.title + "\n" + bm.url);
                label.setTextSize(13);
                label.setOnClickListener(v -> { load(bm.url); closeBookmarksPanel(); });

                Button moveBtn = new Button(this);
                moveBtn.setText("\uD83D\uDCC1");
                moveBtn.setOnClickListener(v -> showMoveToFolderDialog(bm));

                Button delete = new Button(this);
                delete.setText("\u2715");
                delete.setOnClickListener(v -> {
                    bookmarks.removeByUrl(bm.url);
                    Toast.makeText(this, "Bookmark deleted.", Toast.LENGTH_SHORT).show();
                    refreshBookmarksPanel();
                    updateStarIcon();
                });

                row.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(moveBtn, new LinearLayout.LayoutParams(-2, -2));
                row.addView(delete, new LinearLayout.LayoutParams(-2, -2));
                bookmarksListContainer.addView(row);
            }
        }
    }

    void showMoveToFolderDialog(BookmarkStore.Bookmark bm) {
        List<String> folders = bookmarks.allFolders();
        String[] options = new String[folders.size() + 1];
        for (int i = 0; i < folders.size(); i++) options[i] = folders.get(i);
        options[folders.size()] = "+ New Folder";

        new AlertDialog.Builder(this)
            .setTitle("Move \"" + bm.title + "\" to")
            .setItems(options, (d, which) -> {
                if (which == folders.size()) {
                    final EditText input = new EditText(this);
                    input.setHint("Folder name");
                    new AlertDialog.Builder(this)
                        .setTitle("New Folder")
                        .setView(input)
                        .setPositiveButton("Create & Move", (d2, w2) -> {
                            String name = input.getText().toString().trim();
                            if (name.isEmpty()) return;
                            bookmarks.setFolder(bm.url, name);
                            refreshBookmarksPanel();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                } else {
                    bookmarks.setFolder(bm.url, folders.get(which));
                    refreshBookmarksPanel();
                }
            })
            .show();
    }

    // ================= HISTORY =================

    void showHistoryDialog() {
        List<HistoryStore.Entry> list = history.all();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30, 20, 30, 0);

        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No history yet.");
            l.addView(empty);
        } else {
            SimpleDateFormat fmt = new SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault());
            for (HistoryStore.Entry e : list) {
                Button row = new Button(this);
                row.setText(fmt.format(new Date(e.time)) + "\n" + e.title);
                row.setOnClickListener(v -> load(e.url));
                l.addView(row);
            }
        }

        Button clearBtn = new Button(this);
        clearBtn.setText("Clear History");
        clearBtn.setOnClickListener(v -> {
            history.clear();
            Toast.makeText(this, "History cleared.", Toast.LENGTH_SHORT).show();
        });
        l.addView(clearBtn);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("History").setView(sv).setPositiveButton("Close", null).show();
    }

    // ================= HOMEPAGE =================

    String homepage() {
        return cfg.getString("homepage", DEFAULT_HOMEPAGE);
    }

    // ---- speed-dial new tab page ----

    void loadSpeedDial() {
        StringBuilder tiles = new StringBuilder();
        List<BookmarkStore.Bookmark> bm = bookmarks.all();
        for (int i = 0; i < Math.min(8, bm.size()); i++) {
            tiles.append(speedDialTile(bm.get(i).title, bm.get(i).url));
        }
        List<HistoryStore.Entry> hist = history.all();
        int added = 0;
        for (HistoryStore.Entry e : hist) {
            if (added >= 8) break;
            boolean dup = false;
            for (BookmarkStore.Bookmark b : bm) if (b.url.equals(e.url)) { dup = true; break; }
            if (dup) continue;
            tiles.append(speedDialTile(e.title, e.url));
            added++;
        }
        if (tiles.length() == 0) {
            tiles.append("<p style='color:#888;font-family:sans-serif;'>Your bookmarks and recently visited sites will show up here.</p>");
        }
        String html = "<html><body style='margin:0;padding:24px;font-family:sans-serif;background:#F5F6FA;'>" +
            "<h2 style='color:#3B2A9E;'>New Tab</h2>" +
            "<div style='display:flex;flex-wrap:wrap;gap:12px;'>" + tiles + "</div>" +
            "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    String speedDialTile(String title, String url) {
        String safeTitle = title == null ? url : title.replace("<", "&lt;");
        if (safeTitle.length() > 22) safeTitle = safeTitle.substring(0, 22) + "\u2026";
        return "<a href='" + url + "' style='display:block;width:120px;padding:16px;border-radius:12px;" +
            "background:white;box-shadow:0 1px 4px rgba(0,0,0,0.15);text-decoration:none;color:#3B2A9E;" +
            "font-size:13px;text-align:center;'>" + safeTitle + "</a>";
    }

    void showHomepageDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 20, 40, 0);

        TextView current = new TextView(this);
        current.setText("Current homepage:\n" + homepage());
        current.setPadding(0, 0, 0, 20);

        final EditText urlInput = new EditText(this);
        urlInput.setHint("Enter a homepage URL");

        Button useCurrent = new Button(this);
        useCurrent.setText("Use Current Page as Homepage");
        useCurrent.setOnClickListener(v -> {
            String url = String.valueOf(web.getUrl());
            if (url != null && !url.equals("null")) urlInput.setText(url);
        });

        Button reset = new Button(this);
        reset.setText("Reset Homepage");
        reset.setOnClickListener(v -> urlInput.setText(DEFAULT_HOMEPAGE));

        l.addView(current);
        l.addView(urlInput);
        l.addView(useCurrent);
        l.addView(reset);

        new AlertDialog.Builder(this)
            .setTitle("Homepage")
            .setView(l)
            .setPositiveButton("Save", (d, w) -> {
                String u = urlInput.getText().toString().trim();
                if (u.isEmpty()) { Toast.makeText(this, "Please enter a valid URL.", Toast.LENGTH_SHORT).show(); return; }
                if (!u.startsWith("http")) u = "https://" + u;
                cfg.edit().putString("homepage", u).apply();
                Toast.makeText(this, "Homepage saved.", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ================= LICENSE: SITE SCRIPT PREMIUM GATE =================

    void showLicenseRequiredDialog() {
        String msg;
        if ("EXPIRED".equals(lm.status())) {
            msg = "Your license has expired. Please activate a valid license to use Site Scripts.";
        } else if ("ACTIVE".equals(lm.status()) && !lm.termsAccepted()) {
            msg = "The Privacy Policy / Terms of Use have been updated. Please review and accept them again.";
        } else if (lm.hasPendingRequest()) {
            msg = "Your activation request is still PENDING. Enter your license key once you receive it to activate.";
        } else {
            msg = "Site Scripts are a premium feature. Activate a license to use them.";
        }
        new AlertDialog.Builder(this)
            .setTitle("License Required")
            .setMessage(msg)
            .setPositiveButton("Activate License", (d, w) -> showActivationDialog())
            .setNegativeButton("Close", null)
            .show();
    }

    void showSettingsDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 30, 40, 10);

        Button homepageBtn = new Button(this);
        homepageBtn.setText("Homepage");
        homepageBtn.setOnClickListener(v -> showHomepageDialog());
        l.addView(homepageBtn);

        TextView searchLabel = new TextView(this);
        searchLabel.setText("\nSearch Engine");
        l.addView(searchLabel);
        RadioGroup searchGroup = new RadioGroup(this);
        searchGroup.setOrientation(RadioGroup.HORIZONTAL);
        String curEngine = cfg.getString("search_engine", "google");
        String[] engineIds = {"google", "duckduckgo", "bing"};
        String[] engineLabels = {"Google", "DuckDuckGo", "Bing"};
        for (int i = 0; i < engineIds.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(engineLabels[i]);
            String id = engineIds[i];
            rb.setChecked(curEngine.equals(id));
            rb.setOnClickListener(v -> cfg.edit().putString("search_engine", id).apply());
            searchGroup.addView(rb);
        }
        l.addView(searchGroup);

        final CheckBox dataSaver = new CheckBox(this);
        dataSaver.setText("Data Saver (block images)");
        dataSaver.setChecked(cfg.getBoolean("data_saver", false));
        dataSaver.setOnCheckedChangeListener((btn, checked) -> {
            cfg.edit().putBoolean("data_saver", checked).apply();
            applyDataSaverToAllTabs();
            web.reload();
        });
        l.addView(dataSaver);

        final CheckBox adBlock = new CheckBox(this);
        adBlock.setText("Block Common Ad / Tracker Domains (basic list)");
        adBlock.setChecked(cfg.getBoolean("ad_block", true));
        adBlock.setOnCheckedChangeListener((btn, checked) -> {
            cfg.edit().putBoolean("ad_block", checked).apply();
            web.reload();
        });
        l.addView(adBlock);

        Button exportBookmarksBtn = new Button(this);
        exportBookmarksBtn.setText("Export Bookmarks");
        exportBookmarksBtn.setOnClickListener(v -> exportBookmarks());
        l.addView(exportBookmarksBtn);

        Button importBookmarksBtn = new Button(this);
        importBookmarksBtn.setText("Import Bookmarks");
        importBookmarksBtn.setOnClickListener(v -> importBookmarks());
        l.addView(importBookmarksBtn);

        Button exportScriptsBtn = new Button(this);
        exportScriptsBtn.setText("Export Site Scripts");
        exportScriptsBtn.setOnClickListener(v -> exportScripts());
        l.addView(exportScriptsBtn);

        Button importScriptsBtn = new Button(this);
        importScriptsBtn.setText("Import Site Scripts");
        importScriptsBtn.setOnClickListener(v -> importScripts());
        l.addView(importScriptsBtn);

        TextView status = new TextView(this);
        String s = lm.status();
        StringBuilder sb = new StringBuilder();
        sb.append("\nLicense Status\n");
        if (lm.hasPendingRequest() && !"ACTIVE".equals(s)) {
            sb.append("PENDING (activation request submitted)\n");
        } else {
            sb.append(s.equals("NOT_ACTIVATED") ? "NOT ACTIVATED" : s).append("\n");
        }
        sb.append("\n");
        if (s.equals("ACTIVE")) {
            sb.append("Expiry Date: ").append(lm.expiryDate()).append("\n");
            sb.append("Days Remaining: ").append(lm.daysRemaining()).append("\n");
            sb.append("License Key: ").append(lm.licenseKey()).append("\n");
        } else if (s.equals("EXPIRED")) {
            sb.append("Expiry Date: ").append(lm.expiryDate()).append("\n");
        }
        status.setText(sb.toString());
        status.setPadding(0, 0, 0, 20);
        l.addView(status);

        Button activateBtn = new Button(this);
        activateBtn.setText(s.equals("ACTIVE") ? "License Details / Reactivate" : "Activate License");
        activateBtn.setOnClickListener(v -> showActivationDialog());
        l.addView(activateBtn);

        Button refreshBtn = new Button(this);
        refreshBtn.setText("Refresh Status from Server");
        refreshBtn.setOnClickListener(v -> lm.checkLicense((ok, m) ->
            Toast.makeText(this, ok ? ("Status: " + m) : "Could not reach the server.", Toast.LENGTH_SHORT).show()));
        l.addView(refreshBtn);

        Button privacyBtn = new Button(this);
        privacyBtn.setText("Privacy Policy");
        privacyBtn.setOnClickListener(v -> showTextDialog("Privacy Policy", PRIVACY_POLICY_TEXT));
        l.addView(privacyBtn);

        Button termsBtn = new Button(this);
        termsBtn.setText("Terms of Use");
        termsBtn.setOnClickListener(v -> showTextDialog("Terms of Use", TERMS_OF_USE_TEXT));
        l.addView(termsBtn);

        Button respBtn = new Button(this);
        respBtn.setText("Responsible Use / Disclaimer");
        respBtn.setOnClickListener(v -> showTextDialog("Responsible Use / Disclaimer", RESPONSIBLE_USE_TEXT));
        l.addView(respBtn);

        TextView about = new TextView(this);
        about.setText("\nAbout\nMy Browser - a lightweight Android browser with tabs, bookmarks, history, DevTools and optional premium Site Scripts.");
        l.addView(about);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("Settings").setView(sv).setPositiveButton("Close", null).show();
    }

    void showTextDialog(String title, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextIsSelectable(true);
        tv.setPadding(40, 30, 40, 30);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show();
    }

    void showActivationDialog() {
        boolean pending = lm.hasPendingRequest() && !"ACTIVE".equals(lm.status());

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 20, 40, 0);

        final EditText name = new EditText(this);
        final EditText mobile = new EditText(this);
        final EditText address = new EditText(this);
        final EditText key = new EditText(this);
        key.setHint("License Key");

        if (pending) {
            // A request was already submitted: only ask for the License Key.
            TextView statusTv = new TextView(this);
            SimpleDateFormat fmt = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault());
            statusTv.setText("Activation Request Status: PENDING\nSubmitted: " + fmt.format(new Date(lm.pendingAt())) +
                "\nName: " + lm.pendingName() + "\nMobile: " + lm.pendingMobile() +
                "\n\nAlready have a license key? Enter it below to activate.");
            statusTv.setPadding(0, 0, 0, 16);
            l.addView(statusTv);
            name.setText(lm.pendingName());
            mobile.setText(lm.pendingMobile());
            address.setText(lm.pendingAddress());
        } else {
            name.setHint("Name");
            mobile.setHint("Mobile Number");
            mobile.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            address.setHint("Address");
            l.addView(name);
            l.addView(mobile);
            l.addView(address);
        }

        l.addView(key);

        TextView instId = new TextView(this);
        instId.setText("Installation ID: " + lm.installationId());
        instId.setTextSize(11);
        instId.setPadding(0, 10, 0, 10);
        l.addView(instId);

        LinearLayout linksRow = new LinearLayout(this);
        linksRow.setOrientation(LinearLayout.HORIZONTAL);
        Button pLink = new Button(this); pLink.setText("Privacy Policy");
        pLink.setOnClickListener(v -> showTextDialog("Privacy Policy", PRIVACY_POLICY_TEXT));
        Button tLink = new Button(this); tLink.setText("Terms of Use");
        tLink.setOnClickListener(v -> showTextDialog("Terms of Use", TERMS_OF_USE_TEXT));
        Button rLink = new Button(this); rLink.setText("Responsible Use");
        rLink.setOnClickListener(v -> showTextDialog("Responsible Use / Disclaimer", RESPONSIBLE_USE_TEXT));
        linksRow.addView(pLink); linksRow.addView(tLink); linksRow.addView(rLink);
        l.addView(linksRow);

        final CheckBox agree = new CheckBox(this);
        agree.setText("I have read and agree to the Privacy Policy, Terms of Use and Responsible Use Policy.");
        agree.setChecked(lm.termsAccepted());
        l.addView(agree);

        final ProgressBar progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        l.addView(progress);

        Button requestBtn = null;
        if (!pending) {
            TextView noKey = new TextView(this);
            noKey.setText("\nDon't have a license key? Submit your details below and we will contact you regarding activation.");
            noKey.setPadding(0, 10, 0, 6);
            l.addView(noKey);

            requestBtn = new Button(this);
            requestBtn.setText("Request Activation");
            l.addView(requestBtn);
        }
        final Button requestBtnFinal = requestBtn;

        ScrollView sv = new ScrollView(this);
        sv.addView(l);

        AlertDialog dlg = new AlertDialog.Builder(this)
            .setTitle(pending ? "Enter License Key" : "Activate License")
            .setView(sv)
            .setPositiveButton("Activate", null)
            .setNegativeButton("Cancel", null)
            .create();

        dlg.setOnShowListener(d -> {
            Button okBtn = dlg.getButton(AlertDialog.BUTTON_POSITIVE);
            Button cancelBtn = dlg.getButton(AlertDialog.BUTTON_NEGATIVE);

            Runnable updateEnabled = () -> {
                okBtn.setEnabled(agree.isChecked());
                if (requestBtnFinal != null) requestBtnFinal.setEnabled(agree.isChecked());
            };
            agree.setOnCheckedChangeListener((btn, checked) -> {
                if (checked) lm.acceptCurrentTerms();
                updateEnabled.run();
            });
            updateEnabled.run();

            okBtn.setOnClickListener(v -> {
                String n = name.getText().toString().trim();
                String m = mobile.getText().toString().trim();
                String a = address.getText().toString().trim();
                String k = key.getText().toString().trim();

                if (n.isEmpty()) { Toast.makeText(this, "Please enter your name.", Toast.LENGTH_SHORT).show(); return; }
                if (!m.matches("^[6-9][0-9]{9}$")) { Toast.makeText(this, "Please enter a valid mobile number.", Toast.LENGTH_SHORT).show(); return; }
                if (a.isEmpty()) { Toast.makeText(this, "Please enter your address.", Toast.LENGTH_SHORT).show(); return; }
                if (k.isEmpty()) { Toast.makeText(this, "Please enter your license key.", Toast.LENGTH_SHORT).show(); return; }
                if (!agree.isChecked()) { Toast.makeText(this, "Please accept the Privacy Policy and Terms of Use.", Toast.LENGTH_SHORT).show(); return; }

                setBusy(true, okBtn, cancelBtn, requestBtnFinal, progress);
                lm.activate(n, m, a, k, (ok, message) -> {
                    setBusy(false, okBtn, cancelBtn, requestBtnFinal, progress);
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    if (ok) { dlg.dismiss(); web.reload(); }
                });
            });

            if (requestBtnFinal != null) {
                requestBtnFinal.setOnClickListener(v -> {
                    String n = name.getText().toString().trim();
                    String m = mobile.getText().toString().trim();
                    String a = address.getText().toString().trim();

                    if (n.isEmpty()) { Toast.makeText(this, "Please enter your name.", Toast.LENGTH_SHORT).show(); return; }
                    if (!m.matches("^[6-9][0-9]{9}$")) { Toast.makeText(this, "Please enter a valid mobile number.", Toast.LENGTH_SHORT).show(); return; }
                    if (a.isEmpty()) { Toast.makeText(this, "Please enter your address.", Toast.LENGTH_SHORT).show(); return; }
                    if (!agree.isChecked()) { Toast.makeText(this, "Please accept the Privacy Policy and Terms of Use.", Toast.LENGTH_SHORT).show(); return; }

                    setBusy(true, okBtn, cancelBtn, requestBtnFinal, progress);
                    lm.requestActivation(n, m, a, (ok, message) -> {
                        setBusy(false, okBtn, cancelBtn, requestBtnFinal, progress);
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                        if (ok) dlg.dismiss();
                    });
                });
            }
        });

        dlg.show();
    }

    void setBusy(boolean busy, Button okBtn, Button cancelBtn, Button requestBtn, ProgressBar progress) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        okBtn.setEnabled(!busy);
        cancelBtn.setEnabled(!busy);
        if (requestBtn != null) requestBtn.setEnabled(!busy);
    }

    static final String PRIVACY_POLICY_TEXT =
        "Privacy Policy\n\n" +
        "License activation: when you activate a license, we send your name, mobile number, address, " +
        "license key, an installation ID (randomly generated, unique to this install), and basic device " +
        "information (Android version, device manufacturer/model, app version) to our license server.\n\n" +
        "Activation request: if you submit a request without a license key, we send your name, mobile " +
        "number, address, installation ID and device information so we can contact you about activation.\n\n" +
        "License check: the app periodically checks your license status by sending only the installation ID.\n\n" +
        "This information is used only for license activation, validation, 31-day license management, " +
        "processing activation requests, and preventing unauthorized license sharing.\n\n" +
        "Your web browsing data (history, passwords, cookies, page content, form data) is never sent to the " +
        "license server. Bookmarks and history are stored only on this device.\n\n" +
        "License validation uses a Google Apps Script / Google Sheets backend.";

    static final String TERMS_OF_USE_TEXT =
        "Terms of Use\n\n" +
        "This application is a browser with an optional premium Site Script (custom JavaScript injection) " +
        "feature intended for website testing and development.\n\n" +
        "Site Scripts are intended for authorized testing and development only. Only use them on websites " +
        "or systems you are authorized to test, and comply with all applicable laws.\n\n" +
        "A license activation grants 31 days of Site Script access. Sharing a license or bypassing the " +
        "activation system is not permitted.\n\n" +
        "The developer does not encourage or authorize any illegal or unauthorized activity.";

    static final String RESPONSIBLE_USE_TEXT =
        "Responsible Use / Disclaimer\n\n" +
        "This application is primarily intended for website testing, web development, JavaScript testing, " +
        "debugging, and educational purposes, on websites or systems owned by or authorized for the user.\n\n" +
        "You are responsible for how you use the application's features. Only test websites or systems you " +
        "are authorized to test.\n\n" +
        "The developer does not authorize or encourage unauthorized access, credential theft, fraud, " +
        "privacy violations, malware distribution, data theft, system disruption, or any other unlawful " +
        "activity.\n\n" +
        "If a user uses the application for illegal, unauthorized, harmful or abusive purposes, that user " +
        "is responsible for such use and its consequences, subject to applicable law.";

    // ================= SITE SCRIPTS =================

    String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return "";
            h = h.toLowerCase().trim();
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) {
            return "";
        }
    }

    String normalizeDomain(String raw) {
        String d = raw.trim();
        if (d.equals("*")) return d;
        d = d.replaceFirst("^[a-zA-Z]+://", "");
        int slash = d.indexOf('/');
        if (slash >= 0) d = d.substring(0, slash);
        int colon = d.indexOf(':');
        if (colon >= 0) d = d.substring(0, colon);
        d = d.toLowerCase().trim();
        if (d.startsWith("www.")) d = d.substring(4);
        return d;
    }

    void runAlwaysScripts(WebView v, String host) {
        if (!featureEnabled()) return;
        if (!lm.isSiteScriptAllowed()) return; // license gate - real injection path
        List<Script> list = scripts.matching(host, Script.MODE_ALWAYS);
        for (Script s : list) v.evaluateJavascript(s.code, null);
    }

    void updateRunScriptFab(String host) {
        if (!featureEnabled()) { runScriptFab.setVisibility(View.GONE); return; }
        List<Script> manual = scripts.matching(host, Script.MODE_MANUAL);
        runScriptFab.setVisibility(manual.isEmpty() ? View.GONE : View.VISIBLE);
    }

    void onRunScriptTapped() {
        if (!featureEnabled()) {
            Toast.makeText(this, "Site Script feature is turned off. Unlock it from DevTools.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!lm.isSiteScriptAllowed()) {
            showLicenseRequiredDialog();
            return;
        }
        String host = hostOf(String.valueOf(web.getUrl()));
        List<Script> manual = scripts.matching(host, Script.MODE_MANUAL);
        if (manual.isEmpty()) {
            Toast.makeText(this, "No saved script matches \"" + host + "\".", Toast.LENGTH_SHORT).show();
            return;
        }
        if (manual.size() == 1) {
            web.evaluateJavascript(manual.get(0).code, null);
            Toast.makeText(this, "Script executed.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[manual.size()];
        for (int i = 0; i < manual.size(); i++) labels[i] = manual.get(i).domain;
        new AlertDialog.Builder(this)
            .setTitle("Scripts")
            .setItems(labels, (d, i) -> {
                web.evaluateJavascript(manual.get(i).code, null);
                Toast.makeText(this, "Script executed.", Toast.LENGTH_SHORT).show();
            })
            .show();
    }

    void showScriptListDialog() {
        if (!featureEnabled() || !lm.isSiteScriptAllowed()) {
            showLicenseRequiredDialog();
            return;
        }
        List<Script> list = scripts.all();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30, 20, 30, 0);

        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No Site Scripts saved yet.");
            l.addView(empty);
        } else {
            for (Script sItem : list) {
                Button row = new Button(this);
                String badge = sItem.mode.equals(Script.MODE_ALWAYS) ? "[ALWAYS]" : "[MANUAL]";
                String state = sItem.enabled ? "" : " (disabled)";
                row.setText(badge + " " + sItem.domain + state);
                row.setOnClickListener(v -> showScriptEditor(sItem));
                l.addView(row);
            }
        }

        Button addBtn = new Button(this);
        addBtn.setText("+ Add New Site Script");
        addBtn.setOnClickListener(v -> showScriptEditor(null));
        l.addView(addBtn);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("Site Scripts").setView(sv).setPositiveButton("Close", null).show();
    }

    void showScriptEditor(Script existing) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 20, 40, 0);

        final EditText domain = new EditText(this);
        domain.setHint("Website / Domain (e.g. example.com, or * for all sites)");
        domain.setSingleLine(true);

        final EditText code = new EditText(this);
        code.setHint("JavaScript Code");
        code.setMinLines(8);
        code.setGravity(Gravity.TOP);

        final CheckBox enabled = new CheckBox(this);
        enabled.setText("Enabled");
        enabled.setChecked(true);

        TextView modeLabel = new TextView(this);
        modeLabel.setText("Execution:");
        modeLabel.setPadding(0, 10, 0, 0);

        final RadioGroup modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton alwaysRb = new RadioButton(this);
        alwaysRb.setText("Always Run");
        alwaysRb.setId(View.generateViewId());
        RadioButton manualRb = new RadioButton(this);
        manualRb.setText("Manual");
        manualRb.setId(View.generateViewId());
        modeGroup.addView(alwaysRb);
        modeGroup.addView(manualRb);
        modeGroup.check(manualRb.getId());

        if (existing != null) {
            domain.setText(existing.domain);
            code.setText(existing.code);
            enabled.setChecked(existing.enabled);
            modeGroup.check(existing.mode.equals(Script.MODE_ALWAYS) ? alwaysRb.getId() : manualRb.getId());
        } else {
            domain.setText(hostOf(String.valueOf(web.getUrl())));
        }

        l.addView(domain);
        l.addView(code);
        l.addView(enabled);
        l.addView(modeLabel);
        l.addView(modeGroup);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
            .setTitle(existing == null ? "New Site Script" : "Edit Site Script")
            .setView(sv)
            .setPositiveButton("Save", (d, w) -> {
                String h = normalizeDomain(domain.getText().toString());
                if (h.isEmpty()) { Toast.makeText(this, "Please enter a website or domain.", Toast.LENGTH_SHORT).show(); return; }

                Script s = (existing != null) ? existing : new Script();
                s.domain = h;
                s.code = code.getText().toString();
                s.enabled = enabled.isChecked();
                s.mode = (modeGroup.getCheckedRadioButtonId() == alwaysRb.getId()) ? Script.MODE_ALWAYS : Script.MODE_MANUAL;
                scripts.save(s);
                Toast.makeText(this, "Site Script saved.", Toast.LENGTH_SHORT).show();
                web.reload();
            })
            .setNegativeButton("Cancel", null);

        if (existing != null) {
            builder.setNeutralButton("Delete", (d, w) -> {
                scripts.delete(existing.id);
                Toast.makeText(this, "Site Script deleted.", Toast.LENGTH_SHORT).show();
                runScriptFab.setVisibility(View.GONE);
            });
        }

        builder.show();
    }

    // ================= BROWSER BASICS =================

    boolean looksLikeUrl(String s) {
        if (s.contains(" ")) return false;
        if (s.startsWith("http://") || s.startsWith("https://")) return true;
        return s.contains(".") && !s.startsWith(".") && !s.endsWith(".");
    }

    String searchUrl(String query) {
        String enc;
        try { enc = java.net.URLEncoder.encode(query, "UTF-8"); } catch (Exception e) { enc = query; }
        String engine = cfg.getString("search_engine", "google");
        switch (engine) {
            case "duckduckgo": return "https://duckduckgo.com/?q=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            default: return "https://www.google.com/search?q=" + enc;
        }
    }

    void load(String raw) {
        String u = raw.trim();
        if (u.isEmpty()) return;
        if (u.equals("about:newtab")) { loadSpeedDial(); return; }
        if (looksLikeUrl(u)) {
            if (!u.startsWith("http")) u = "https://" + u;
        } else {
            u = searchUrl(u);
        }
        web.loadUrl(u);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (req == REQ_EXPORT_BOOKMARKS) {
                writeTextToUri(uri, bookmarks.exportJson());
                Toast.makeText(this, "Bookmarks exported.", Toast.LENGTH_SHORT).show();
            } else if (req == REQ_IMPORT_BOOKMARKS) {
                int added = bookmarks.importJson(readTextFromUri(uri));
                Toast.makeText(this, added + " bookmark(s) imported.", Toast.LENGTH_SHORT).show();
                refreshBookmarksPanel();
            } else if (req == REQ_EXPORT_SCRIPTS) {
                writeTextToUri(uri, scripts.exportJson());
                Toast.makeText(this, "Site Scripts exported.", Toast.LENGTH_SHORT).show();
            } else if (req == REQ_IMPORT_SCRIPTS) {
                int added = scripts.importJson(readTextFromUri(uri));
                Toast.makeText(this, added + " script(s) imported.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "That didn't work. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        if (k == KeyEvent.KEYCODE_BACK && bookmarksPanel.getVisibility() == View.VISIBLE) { closeBookmarksPanel(); return true; }
        if (k == KeyEvent.KEYCODE_BACK && findBar.getVisibility() == View.VISIBLE) { findBar.setVisibility(View.GONE); web.clearMatches(); return true; }
        if (k == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true; }
        if (k == KeyEvent.KEYCODE_BACK && tabs.size() > 1) { closeTab(currentTabIndex); return true; }
        return super.onKeyDown(k, e);
    }
}
