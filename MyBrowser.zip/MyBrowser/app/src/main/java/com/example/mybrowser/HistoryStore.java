package com.example.mybrowser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HistoryStore {

    public static class Entry {
        public String title;
        public String url;
        public long time;
        public Entry(String t, String u, long ts) { title = t; url = u; time = ts; }
    }

    private static final int MAX_ENTRIES = 200;
    private final SharedPreferences sp;

    public HistoryStore(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("history_v1", Context.MODE_PRIVATE);
    }

    public List<Entry> all() {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString("list", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Entry(o.optString("title", ""), o.optString("url", ""), o.optLong("time", 0L)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public void add(String title, String url) {
        if (url == null || url.isEmpty() || url.equals("null")) return;
        List<Entry> list = all();
        // move to top if the same URL was visited again
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).url.equals(url)) { list.remove(i); break; }
        }
        list.add(0, new Entry((title == null || title.isEmpty()) ? url : title, url, System.currentTimeMillis()));
        while (list.size() > MAX_ENTRIES) list.remove(list.size() - 1);
        save(list);
    }

    public void clear() {
        sp.edit().putString("list", "[]").apply();
    }

    private void save(List<Entry> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("title", e.title);
                o.put("url", e.url);
                o.put("time", e.time);
                arr.put(o);
            }
            sp.edit().putString("list", arr.toString()).apply();
        } catch (Exception ignored) {}
    }
}
