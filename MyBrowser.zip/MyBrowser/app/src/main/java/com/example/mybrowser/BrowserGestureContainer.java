package com.example.mybrowser;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.webkit.WebView;
import android.widget.FrameLayout;

/**
 * Wraps the active WebView to add two gestures that WebView itself doesn't
 * expose in plain Android (no SwipeRefreshLayout / androidx available here):
 *  - Pull-down-to-refresh, only when the page is scrolled to the very top.
 *  - Edge-swipe back/forward, only when the drag starts near the left/right edge.
 * It only intercepts touches that clearly match one of these gestures; everything
 * else (normal scrolling, pinch-zoom, tapping links) passes straight to the WebView.
 */
public class BrowserGestureContainer extends FrameLayout {

    public interface Listener {
        WebView currentWebView();
        void onPullToRefresh();
        void onEdgeSwipeBack();
        void onEdgeSwipeForward();
        void onPullProgress(float progress); // 0f..1f, for showing an indicator
        void onPullCancelled();
    }

    private Listener listener;
    private final int touchSlop;
    private final int edgeZonePx;
    private final float pullThresholdPx;

    private float downX, downY;
    private boolean draggingDown = false;
    private boolean draggingEdge = false;
    private boolean edgeIsLeft = false;
    private boolean decided = false;

    public BrowserGestureContainer(Context c) {
        super(c);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
        edgeZonePx = (int) (24 * c.getResources().getDisplayMetrics().density);
        pullThresholdPx = 90 * c.getResources().getDisplayMetrics().density;
    }

    public void setListener(Listener l) { listener = l; }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (listener == null) return false;
        WebView wv = listener.currentWebView();
        if (wv == null) return false;

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = ev.getX();
                downY = ev.getY();
                draggingDown = false;
                draggingEdge = false;
                decided = false;
                edgeIsLeft = downX <= edgeZonePx;
                boolean edgeRight = downX >= getWidth() - edgeZonePx;
                // remember candidate edge; real decision happens on first sizeable move
                if (edgeIsLeft || edgeRight) edgeIsLeft = edgeIsLeft; // keep flag; edgeRight checked again below
                return false; // never steal DOWN; decide on MOVE

            case MotionEvent.ACTION_MOVE:
                if (decided) return draggingDown || draggingEdge;
                float dx = ev.getX() - downX;
                float dy = ev.getY() - downY;
                if (Math.abs(dx) < touchSlop && Math.abs(dy) < touchSlop) return false;

                boolean startedAtLeftEdge = downX <= edgeZonePx;
                boolean startedAtRightEdge = downX >= getWidth() - edgeZonePx;

                if ((startedAtLeftEdge || startedAtRightEdge) && Math.abs(dx) > Math.abs(dy)) {
                    draggingEdge = true;
                    edgeIsLeft = startedAtLeftEdge;
                    decided = true;
                    return true;
                }
                if (dy > 0 && Math.abs(dy) > Math.abs(dx) && wv.getScrollY() <= 0) {
                    draggingDown = true;
                    decided = true;
                    return true;
                }
                decided = true; // normal scroll/zoom, let WebView handle it
                return false;

            default:
                return false;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (listener == null) return false;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                if (draggingDown) {
                    float dy = Math.max(0, ev.getY() - downY);
                    listener.onPullProgress(Math.min(1f, dy / pullThresholdPx));
                    return true;
                }
                if (draggingEdge) {
                    return true; // consumed; visual feedback optional, keep it simple
                }
                return false;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (draggingDown) {
                    float dy = Math.max(0, ev.getY() - downY);
                    if (dy >= pullThresholdPx) listener.onPullToRefresh();
                    else listener.onPullCancelled();
                    draggingDown = false;
                    return true;
                }
                if (draggingEdge) {
                    float dx = ev.getX() - downX;
                    int minSwipe = (int) (60 * getResources().getDisplayMetrics().density);
                    if (edgeIsLeft && dx > minSwipe) listener.onEdgeSwipeBack();
                    else if (!edgeIsLeft && dx < -minSwipe) listener.onEdgeSwipeForward();
                    draggingEdge = false;
                    return true;
                }
                return false;

            default:
                return false;
        }
    }
}
