package com.example.mybrowser;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.UUID;

/**
 * Centralized license handling for the premium Site Script feature.
 * Normal browsing never depends on this class.
 */
public class LicenseManager {

    // ---- centralized configuration (do not duplicate elsewhere) ----
    public static final String LICENSE_API_URL =
        "https://script.google.com/macros/s/AKfycbyFBFyMfffD2uEMCLFo-xMGDz-9X0XILnhh1ElXyBTMBXWARahtmh2UlopROHc8UVds/exec";
    public static final String TERMS_VERSION = "1.0";

    private static final String PREFS = "license_config";

    private final Context ctx;
    private final SharedPreferences sp;
    private final Handler main = new Handler(Looper.getMainLooper());

    public interface Callback {
        void onResult(boolean success, String message);
    }

    public LicenseManager(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!sp.contains("installation_id")) {
            sp.edit().putString("installation_id", UUID.randomUUID().toString()).apply();
        }
    }

    // ---- local state readers ----

    public String installationId() { return sp.getString("installation_id", ""); }
    public String status() { return sp.getString("status", "NOT_ACTIVATED"); }
    public String licenseKey() { return sp.getString("license_key", ""); }
    public String expiryDate() { return sp.getString("expiry_date", ""); }
    public int daysRemaining() { return sp.getInt("days_remaining", 0); }

    // ---- pending activation request tracking (local) ----

    public boolean hasPendingRequest() {
        return sp.getBoolean("request_pending", false);
    }

    public String pendingName() { return sp.getString("pending_name", ""); }
    public String pendingMobile() { return sp.getString("pending_mobile", ""); }
    public String pendingAddress() { return sp.getString("pending_address", ""); }
    public long pendingAt() { return sp.getLong("pending_at", 0L); }

    public boolean termsAccepted() {
        return sp.getBoolean("terms_accepted", false)
            && TERMS_VERSION.equals(sp.getString("terms_version", ""));
    }

    public void acceptCurrentTerms() {
        sp.edit()
          .putBoolean("terms_accepted", true)
          .putString("terms_version", TERMS_VERSION)
          .putLong("terms_accepted_at", System.currentTimeMillis())
          .apply();
    }

    /** The single source of truth the rest of the app must check before running a Site Script. */
    public boolean isSiteScriptAllowed() {
        return "ACTIVE".equals(status()) && termsAccepted();
    }

    String deviceInfo() {
        return Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE
            + ", app 1.0";
    }

    // ---- activation ----

    public void activate(String name, String mobile, String address, String key, Callback cb) {
        if (!termsAccepted()) {
            cb.onResult(false, "Please accept the Privacy Policy and Terms of Use first.");
            return;
        }
        new Thread(() -> {
            try {
                JSONObject req = new JSONObject();
                req.put("action", "activate");
                req.put("licenseKey", key);
                req.put("name", name);
                req.put("mobile", mobile);
                req.put("address", address);
                req.put("installationId", installationId());
                req.put("deviceInfo", deviceInfo());

                JSONObject res = postJson(req);
                boolean ok = res.optBoolean("success", false);
                if (ok) {
                    String st = res.optString("status", "ACTIVE");
                    sp.edit()
                      .putString("status", st)
                      .putString("license_key", res.optString("licenseKey", key))
                      .putString("expiry_date", res.optString("expiryDate", ""))
                      .putString("activated_at", res.optString("activatedAt", ""))
                      .putInt("days_remaining", res.optInt("days", 31))
                      .putLong("last_check", System.currentTimeMillis())
                      .putBoolean("request_pending", false)
                      .apply();
                    deliver(cb, true, res.optString("message", "License activated successfully."));
                } else {
                    deliver(cb, false, friendlyActivateError(res));
                }
            } catch (Exception e) {
                deliver(cb, false, "Could not reach the activation server. Please check your internet connection and try again.");
            }
        }).start();
    }

    private String friendlyActivateError(JSONObject res) {
        String msg = res.optString("message", "");
        if (!msg.isEmpty()) return msg;
        return "Could not activate the license. Please check your license key.";
    }

    // ---- request activation (no license key yet) ----

    public void requestActivation(String name, String mobile, String address, Callback cb) {
        if (!termsAccepted()) {
            cb.onResult(false, "Please accept the Privacy Policy and Terms of Use first.");
            return;
        }
        new Thread(() -> {
            try {
                JSONObject req = new JSONObject();
                req.put("action", "requestActivation");
                req.put("name", name);
                req.put("mobile", mobile);
                req.put("address", address);
                req.put("installationId", installationId());
                req.put("deviceInfo", deviceInfo());

                JSONObject res = postJson(req);
                boolean ok = res.optBoolean("success", false);
                if (ok) {
                    sp.edit()
                      .putBoolean("request_pending", true)
                      .putString("pending_name", name)
                      .putString("pending_mobile", mobile)
                      .putString("pending_address", address)
                      .putLong("pending_at", System.currentTimeMillis())
                      .apply();
                    deliver(cb, true, "Your activation request has been submitted successfully. We will contact you using the contact information you provided.");
                } else {
                    String msg = res.optString("message", "");
                    deliver(cb, false, msg.isEmpty() ? "Could not submit your request. Please try again." : msg);
                }
            } catch (Exception e) {
                deliver(cb, false, "Could not reach the server. Please check your internet connection and try again.");
            }
        }).start();
    }

    // ---- periodic / on-demand check ----

    public void checkLicense(Callback cb) {
        new Thread(() -> {
            try {
                JSONObject req = new JSONObject();
                req.put("action", "check");
                req.put("installationId", installationId());

                JSONObject res = postJson(req);
                boolean ok = res.optBoolean("success", false);
                if (!ok) {
                    if (cb != null) deliver(cb, false, "offline");
                    return;
                }

                String st = res.optString("status", status());
                SharedPreferences.Editor e = sp.edit();
                if ("ACTIVE".equals(st)) {
                    e.putString("status", "ACTIVE");
                    e.putString("license_key", res.optString("licenseKey", licenseKey()));
                    e.putString("expiry_date", res.optString("expiryDate", expiryDate()));
                    e.putInt("days_remaining", res.optInt("daysRemaining", 0));
                    e.putBoolean("request_pending", false);
                } else if ("EXPIRED".equals(st)) {
                    e.putString("status", "EXPIRED");
                    e.putString("expiry_date", res.optString("expiryDate", expiryDate()));
                } else if ("NOT_ACTIVATED".equals(st)) {
                    e.putString("status", "NOT_ACTIVATED");
                }
                e.putLong("last_check", System.currentTimeMillis());
                e.apply();
                if (cb != null) deliver(cb, true, st);
            } catch (Exception e) {
                // Network failure must NOT flip ACTIVE -> EXPIRED. Keep last known state.
                if (cb != null) deliver(cb, false, "offline");
            }
        }).start();
    }

    private void deliver(Callback cb, boolean ok, String msg) {
        main.post(() -> cb.onResult(ok, msg));
    }

    private JSONObject postJson(JSONObject body) throws Exception {
        URL url = new URL(LICENSE_API_URL);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes("UTF-8"));
        }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        if (is == null) return new JSONObject();
        Scanner sc = new Scanner(is, "UTF-8").useDelimiter("\\A");
        String text = sc.hasNext() ? sc.next() : "";
        if (text.trim().isEmpty()) return new JSONObject();
        return new JSONObject(text);
    }
}
