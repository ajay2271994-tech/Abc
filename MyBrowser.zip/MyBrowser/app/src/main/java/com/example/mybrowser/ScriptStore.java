package com.example.mybrowser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ScriptStore {
    private final SharedPreferences sp;

    public ScriptStore(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("scripts_v2", Context.MODE_PRIVATE);
    }

    public List<Script> all() {
        List<Script> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString("list", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                out.add(Script.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void saveAll(List<Script> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Script s : list) arr.put(s.toJson());
            sp.edit().putString("list", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public Script save(Script s) {
        List<Script> list = all();
        if (s.id == null || s.id.isEmpty()) {
            s.id = UUID.randomUUID().toString();
            list.add(s);
        } else {
            boolean found = false;
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).id.equals(s.id)) { list.set(i, s); found = true; break; }
            }
            if (!found) list.add(s);
        }
        saveAll(list);
        return s;
    }

    public void delete(String id) {
        List<Script> list = all();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(id)) { list.remove(i); break; }
        }
        saveAll(list);
    }

    public String exportJson() {
        try {
            JSONArray arr = new JSONArray();
            for (Script s : all()) arr.put(s.toJson());
            return arr.toString(2);
        } catch (Exception e) {
            return "[]";
        }
    }

    public int importJson(String json) {
        int added = 0;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                Script s = Script.fromJson(arr.getJSONObject(i));
                s.id = null; // force a new id so imported scripts never collide with existing ones
                save(s);
                added++;
            }
        } catch (Exception ignored) {}
        return added;
    }

    public List<Script> matching(String host, String mode) {
        List<Script> out = new ArrayList<>();
        for (Script s : all()) {
            if (s.enabled && s.mode.equals(mode) && s.matches(host)) out.add(s);
        }
        return out;
    }
}
