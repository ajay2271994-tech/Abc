package com.example.mybrowser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ReadingListStore {

    public static class Item {
        public String title;
        public String url;
        public boolean read;
        public Item(String t, String u, boolean r) { title = t; url = u; read = r; }
    }

    private final SharedPreferences sp;

    public ReadingListStore(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("reading_list_v1", Context.MODE_PRIVATE);
    }

    public List<Item> all() {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString("list", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Item(o.optString("title", ""), o.optString("url", ""), o.optBoolean("read", false)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void saveAll(List<Item> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Item it : list) {
                JSONObject o = new JSONObject();
                o.put("title", it.title);
                o.put("url", it.url);
                o.put("read", it.read);
                arr.put(o);
            }
            sp.edit().putString("list", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public boolean contains(String url) {
        for (Item i : all()) if (i.url.equals(url)) return true;
        return false;
    }

    public void add(String title, String url) {
        List<Item> list = all();
        for (Item i : list) if (i.url.equals(url)) return;
        list.add(0, new Item(title, url, false));
        saveAll(list);
    }

    public void remove(String url) {
        List<Item> list = all();
        for (int i = 0; i < list.size(); i++) if (list.get(i).url.equals(url)) { list.remove(i); break; }
        saveAll(list);
    }

    public void markRead(String url, boolean read) {
        List<Item> list = all();
        for (Item i : list) if (i.url.equals(url)) { i.read = read; break; }
        saveAll(list);
    }
}
